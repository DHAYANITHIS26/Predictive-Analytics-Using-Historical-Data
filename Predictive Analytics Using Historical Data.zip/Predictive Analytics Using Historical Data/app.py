import streamlit as st
import pandas as pd
import numpy as np
import datetime
import os
import io

# Import local utilities
from utils.data_loader import load_data, validate_schema, clean_data, prepare_monthly_data
from utils.eda_plots import (
    plot_sales_trend, plot_sales_by_period, plot_product_analysis,
    plot_regional_analysis, plot_customer_analysis, plot_repeat_customers,
    plot_profit_analysis, plot_correlation_heatmap, plot_sales_vs_profit_scatter
)
from utils.models import prepare_train_test_split, train_and_evaluate_models, forecast_recursive
from utils.forecasting import train_and_evaluate_time_series, generate_future_forecasts
from utils.report_generator import generate_pdf_report

# Page Config
st.set_page_config(
    page_title="Sales Forecasting & Predictive Analytics",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom responsive CSS utilizing Streamlit theme variables
st.markdown("""
<style>
    /* Styling for premium card displays */
    .metric-card {
        background-color: var(--secondary-background-color);
        color: var(--text-color);
        border-left: 5px solid var(--primary-color);
        border-radius: 10px;
        padding: 1.2rem;
        margin: 0.5rem 0;
        box-shadow: 0 4px 6px rgba(0,0,0,0.06);
        transition: transform 0.2s;
    }
    .metric-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 12px rgba(0,0,0,0.1);
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 800;
        color: var(--primary-color);
        margin-top: 0.2rem;
    }
    .metric-label {
        font-size: 0.85rem;
        font-weight: 600;
        color: var(--text-color);
        opacity: 0.75;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    /* Section dividers */
    .section-header {
        border-bottom: 2px solid var(--secondary-background-color);
        padding-bottom: 5px;
        margin-bottom: 15px;
        margin-top: 25px;
        font-weight: 700;
    }
</style>
""", unsafe_allow_html=True)

# Initialize Session State
if "raw_df" not in st.session_state:
    st.session_state.raw_df = None
if "cleaned_df" not in st.session_state:
    st.session_state.cleaned_df = None
if "monthly_df" not in st.session_state:
    st.session_state.monthly_df = None
if "cleaning_summary" not in st.session_state:
    st.session_state.cleaning_summary = None
if "has_trained" not in st.session_state:
    st.session_state.has_trained = False
if "model_metrics" not in st.session_state:
    st.session_state.model_metrics = None
if "best_ml_model" not in st.session_state:
    st.session_state.best_ml_model = None
if "trained_models" not in st.session_state:
    st.session_state.trained_models = None
if "ml_predictions" not in st.session_state:
    st.session_state.ml_predictions = None
if "ml_importances" not in st.session_state:
    st.session_state.ml_importances = None
if "ml_features" not in st.session_state:
    st.session_state.ml_features = None
if "ts_metrics" not in st.session_state:
    st.session_state.ts_metrics = None
if "ts_forecasts" not in st.session_state:
    st.session_state.ts_forecasts = None
if "selected_ts_model" not in st.session_state:
    st.session_state.selected_ts_model = None

# Sidebar Navigation
st.sidebar.title("Navigation")
page = st.sidebar.radio(
    "Select a Dashboard Page",
    ["🏠 Home", "📂 Dataset", "🧹 Data Cleaning", "📊 EDA", "🤖 Model Training", "📈 Forecast", "📄 Reports"]
)

# Helper function to compute KPIs
def compute_kpis(df):
    kpis = {}
    if df is not None and not df.empty:
        kpis["total_sales"] = df["Sales"].sum()
        kpis["total_profit"] = df["Profit"].sum()
        kpis["total_orders"] = len(df)
        kpis["avg_order_value"] = df["Sales"].mean()
        kpis["profit_margin"] = (kpis["total_profit"] / kpis["total_sales"]) * 100
        
        # Growth Rate (approximate from month to month)
        monthly_sales = df.set_index("Order Date").resample("ME")["Sales"].sum()
        if len(monthly_sales) > 1:
            growth = monthly_sales.pct_change(1).mean() * 100
            kpis["growth_rate"] = growth
        else:
            kpis["growth_rate"] = 0.0
            
    return kpis

# ----------------- PAGE 1: HOME -----------------
if page == "🏠 Home":
    st.title("🏠 Predictive Analytics Sales Forecasting Dashboard")
    st.write(
        "Welcome to the Sales Forecasting Dashboard, an end-to-end data analytics solution "
        "designed to turn historical order transactions into actionable, forward-looking insights."
    )
    
    # Check if data is loaded
    if st.session_state.cleaned_df is None:
        st.warning("⚠️ No dataset has been loaded yet. Please go to the **📂 Dataset** page to upload or generate data.")
        st.markdown("""
        ### Dashboard Overview & Features
        - **Data Cleaning & Loading**: Upload custom CSV/Excel files and automatically clean missing entries, dates, duplicates, and outliers.
        - **Exploratory Data Analysis (EDA)**: Drill down into sales trends, product margins, regions, and customer frequency.
        - **Supervised Machine Learning**: Train Linear Regression, Random Forest, and XGBoost regressor models to predict sales.
        - **Statistical Time-Series Forecasting**: Generate 12-month future forecasts using SARIMAX, Holt-Winters Exponential Smoothing, and Prophet.
        - **Automated Reporting**: Export point forecasts, cleaned datasets, and download a professional PDF executive report.
        """)
        
        # Shortcut button
        if st.button("Go to Dataset Upload"):
            st.rerun()
    else:
        # Compute summary KPIs
        kpis = compute_kpis(st.session_state.cleaned_df)
        
        st.markdown('<div class="section-header">Historical Sales Performance Summary</div>', unsafe_allow_html=True)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Total Revenue</div>
                <div class="metric-value">${kpis['total_sales']:,.2f}</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col2:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Total Net Profit</div>
                <div class="metric-value" style="color: #2CA02C;">${kpis['total_profit']:,.2f}</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col3:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Total Transactions</div>
                <div class="metric-value" style="color: #FF7F0E;">{kpis['total_orders']:,}</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col4:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Avg Order Value (AOV)</div>
                <div class="metric-value">${kpis['avg_order_value']:,.2f}</div>
            </div>
            """, unsafe_allow_html=True)

        col5, col6, col7, col8 = st.columns(4)
        
        with col5:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Net Profit Margin</div>
                <div class="metric-value">{kpis['profit_margin']:.2f}%</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col6:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">MoM Growth Rate</div>
                <div class="metric-value">{kpis['growth_rate']:+.2f}%</div>
            </div>
            """, unsafe_allow_html=True)
            
        with col7:
            # Forecast KPIs
            if st.session_state.ts_forecasts is not None and st.session_state.selected_ts_model is not None:
                model_name = st.session_state.selected_ts_model
                forecast_df = st.session_state.ts_forecasts[model_name]
                next_month_val = forecast_df["Sales"].iloc[0]
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-label">Next Month Forecast</div>
                    <div class="metric-value">${next_month_val:,.2f}</div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="metric-card">
                    <div class="metric-label">Next Month Forecast</div>
                    <div class="metric-value" style="font-size: 1.1rem; opacity: 0.6; padding: 0.35rem 0;">Run Forecast Page</div>
                </div>
                """, unsafe_allow_html=True)
                
        with col8:
            if st.session_state.ts_forecasts is not None and st.session_state.selected_ts_model is not None:
                model_name = st.session_state.selected_ts_model
                forecast_df = st.session_state.ts_forecasts[model_name]
                next_year_val = forecast_df["Sales"].sum()
                st.markdown(f"""
                <div class="metric-card">
                    <div class="metric-label">Next 12M Forecast</div>
                    <div class="metric-value">${next_year_val:,.2f}</div>
                </div>
                """, unsafe_allow_html=True)
            else:
                st.markdown("""
                <div class="metric-card">
                    <div class="metric-label">Next 12M Forecast</div>
                    <div class="metric-value" style="font-size: 1.1rem; opacity: 0.6; padding: 0.35rem 0;">Run Forecast Page</div>
                </div>
                """, unsafe_allow_html=True)
                
        st.markdown('<div class="section-header">Dashboard Status & Workflow Details</div>', unsafe_allow_html=True)
        
        info_col1, info_col2 = st.columns(2)
        with info_col1:
            st.info(f"📁 **Active Dataset**: Historical Sales Records ({kpis['total_orders']:,} clean rows)")
            st.success("🤖 **Machine Learning Status**: Models " + ("**TRAINED**" if st.session_state.has_trained else "**NOT TRAINED YET** (Go to Model Training page)"))
        with info_col2:
            st.info("📊 **Date Coverage**: " + str(st.session_state.cleaned_df["Order Date"].min().strftime("%b %Y")) + " to " + str(st.session_state.cleaned_df["Order Date"].max().strftime("%b %Y")))
            st.success("📈 **Time-Series Forecast Status**: Forecasts " + ("**COMPLETED**" if st.session_state.ts_forecasts is not None else "**NOT COMPLETED YET** (Go to Forecast page)"))

# ----------------- PAGE 2: DATASET -----------------
elif page == "📂 Dataset":
    st.title("📂 Dataset Manager")
    st.write("Upload your historical sales dataset or load our 5+ year high-quality simulated dataset.")
    
    upload_col, action_col = st.columns([3, 1])
    
    with upload_col:
        uploaded_file = st.file_uploader("Upload Historical Sales Data (CSV or Excel formats)", type=["csv", "xlsx", "xls"])
        
    with action_col:
        st.write("")
        st.write("")
        if st.button("Generate & Load 5-Year Sample Data", use_container_width=True):
            # Run generator script logic or read it if it already exists
            try:
                # If script was already run, we read the CSV directly
                if os.path.exists("data/sample_sales_data.csv"):
                    df = pd.read_csv("data/sample_sales_data.csv")
                else:
                    # Let's import or run it dynamically
                    # We can call python script via subprocess, but reading is cleaner if file is already there.
                    # Since we ran `python generate_sample_data.py` in terminal, it is definitely there.
                    df = pd.read_csv("data/sample_sales_data.csv")
                st.session_state.raw_df = df
                st.session_state.has_trained = False
                st.session_state.ts_forecasts = None
                st.success("✅ Successfully loaded sample database (8,922 records, Jan 2021 - Jun 2026)")
            except Exception as e:
                st.error(f"Could not load sample data: {str(e)}")
                
    if uploaded_file is not None:
        try:
            df = load_data(uploaded_file)
            st.session_state.raw_df = df
            st.session_state.has_trained = False
            st.session_state.ts_forecasts = None
            st.success("✅ File uploaded successfully!")
        except Exception as e:
            st.error(f"Error loading uploaded file: {str(e)}")
            
    if st.session_state.raw_df is not None:
        raw_df = st.session_state.raw_df
        
        # Schema Verification
        is_valid, missing_cols = validate_schema(raw_df)
        
        st.markdown('<div class="section-header">Dataset Schema Validation</div>', unsafe_allow_html=True)
        if is_valid:
            st.success("✅ Schema verified! All required columns are present.")
        else:
            st.error(f"❌ Invalid Schema! Missing required columns: {', '.join(missing_cols)}")
            st.warning("Please upload a CSV containing: " + ", ".join(["Order Date", "Product", "Category", "Customer", "Region", "Quantity", "Unit Price", "Discount", "Sales", "Profit"]))
            
        # Clean Data automatically
        if is_valid:
            if st.session_state.cleaned_df is None:
                # Compute cleaning summary
                before_rows = len(raw_df)
                cleaned = clean_data(raw_df)
                after_rows = len(cleaned)
                duplicates = before_rows - after_rows
                
                # Check missing values in raw
                missing_counts = raw_df.isnull().sum().sum()
                
                st.session_state.cleaned_df = cleaned
                st.session_state.monthly_df = prepare_monthly_data(cleaned)
                st.session_state.cleaning_summary = {
                    "before_rows": before_rows,
                    "after_rows": after_rows,
                    "duplicates_removed": duplicates,
                    "outliers_clipped": "Clipped top 1% (Quantity, Price, Sales)",
                    "missing_values_filled": missing_counts,
                    "engineered_features": 6 # Date components
                }
                
            # Preview and info
            st.markdown('<div class="section-header">Raw Dataset Preview & Information</div>', unsafe_allow_html=True)
            preview_tabs = st.tabs(["📋 Data Preview", "ℹ️ Columns & Data Types", "🔍 Missing Values Analysis"])
            
            with preview_tabs[0]:
                st.dataframe(raw_df.head(10), use_container_width=True)
                st.caption(f"Showing first 10 rows of {len(raw_df):,} total records.")
                
            with preview_tabs[1]:
                info_df = pd.DataFrame({
                    "Data Type": raw_df.dtypes.astype(str),
                    "Non-Null Count": raw_df.notnull().sum(),
                    "Null Count": raw_df.isnull().sum(),
                    "Unique Values": raw_df.nunique()
                })
                st.dataframe(info_df, use_container_width=True)
                
            with preview_tabs[2]:
                nulls = raw_df.isnull().sum().reset_index()
                nulls.columns = ["Column", "Null Count"]
                nulls["Missing %"] = (nulls["Null Count"] / len(raw_df)) * 100
                st.dataframe(nulls, use_container_width=True)

# ----------------- PAGE 3: DATA CLEANING -----------------
elif page == "🧹 Data Cleaning":
    st.title("🧹 Automatic Data Cleaning Pipeline")
    st.write("Review the changes made to standardise your dataset for analysis.")
    
    if st.session_state.cleaned_df is None:
        st.warning("⚠️ No dataset has been loaded. Please go to the **📂 Dataset** page.")
    else:
        summary = st.session_state.cleaning_summary
        
        st.markdown('<div class="section-header">Cleaning Operations Summary</div>', unsafe_allow_html=True)
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Duplicates Removed", f"{summary['duplicates_removed']:,}")
        with col2:
            st.metric("Missing Values Imputed", f"{summary['missing_values_filled']:,}")
        with col3:
            st.metric("Invalid Rows Trimmed", f"{summary['before_rows'] - summary['after_rows'] - summary['duplicates_removed']:,}")
            
        st.markdown('<div class="section-header">Row Count Progression</div>', unsafe_allow_html=True)
        rows_comparison = pd.DataFrame({
            "Stage": ["Uploaded Raw", "Deduplicated & Cleaned"],
            "Rows count": [summary["before_rows"], summary["after_rows"]]
        })
        st.dataframe(rows_comparison, use_container_width=True)
        
        st.markdown('<div class="section-header">Engineered Features List</div>', unsafe_allow_html=True)
        st.write("We have automatically extracted calendar features from the `Order Date` column to assist model training:")
        
        feats = pd.DataFrame({
            "Feature Name": ["Year", "Month", "Quarter", "Week", "Day", "Day of Week"],
            "Derived Value": ["Calendar year (e.g. 2024)", "Month index (1 - 12)", "Quarter (1 - 4)", "ISO Week index", "Day of month (1 - 31)", "Day of week index (0=Monday, 6=Sunday)"]
        })
        st.dataframe(feats, use_container_width=True)
        
        st.markdown('<div class="section-header">Download Cleaned Dataset</div>', unsafe_allow_html=True)
        csv_buffer = io.StringIO()
        st.session_state.cleaned_df.to_csv(csv_buffer, index=False)
        st.download_button(
            label="💾 Download Cleaned CSV",
            data=csv_buffer.getvalue(),
            file_name="cleaned_sales_dataset.csv",
            mime="text/csv",
            use_container_width=True
        )

# ----------------- PAGE 4: EDA -----------------
elif page == "📊 EDA":
    st.title("📊 Exploratory Data Analysis")
    st.write("Filter the cleaned historical records to analyze category contributions, regional profit, and sales trends.")
    
    if st.session_state.cleaned_df is None:
        st.warning("⚠️ No dataset has been loaded. Please go to the **📂 Dataset** page.")
    else:
        cleaned_df = st.session_state.cleaned_df
        
        # Sidebar Filters
        st.sidebar.markdown("### Interactive Filters")
        
        # Product filter
        all_products = sorted(list(cleaned_df["Product"].unique()))
        selected_products = st.sidebar.multiselect("Filter by Product", all_products, default=[])
        
        # Category filter
        all_categories = sorted(list(cleaned_df["Category"].unique()))
        selected_categories = st.sidebar.multiselect("Filter by Category", all_categories, default=[])
        
        # Region filter
        all_regions = sorted(list(cleaned_df["Region"].unique()))
        selected_regions = st.sidebar.multiselect("Filter by Region", all_regions, default=[])
        
        # Year filter
        all_years = sorted(list(cleaned_df["Year"].unique()))
        selected_years = st.sidebar.multiselect("Filter by Year", all_years, default=[])
        
        # Customer filter
        all_customers = sorted(list(cleaned_df["Customer"].unique()))
        selected_customers = st.sidebar.multiselect("Filter by Customer", all_customers, default=[])
        
        # Filter logic
        filtered_df = cleaned_df.copy()
        if selected_products:
            filtered_df = filtered_df[filtered_df["Product"].isin(selected_products)]
        if selected_categories:
            filtered_df = filtered_df[filtered_df["Category"].isin(selected_categories)]
        if selected_regions:
            filtered_df = filtered_df[filtered_df["Region"].isin(selected_regions)]
        if selected_years:
            filtered_df = filtered_df[filtered_df["Year"].isin(selected_years)]
        if selected_customers:
            filtered_df = filtered_df[filtered_df["Customer"].isin(selected_customers)]
            
        if filtered_df.empty:
            st.error("❌ No data matches the selected filter combination. Reset filters in the sidebar.")
        else:
            st.info(f"Showing charts for {len(filtered_df):,} out of {len(cleaned_df):,} records.")
            
            # Sub-sections
            tab_sales, tab_prod, tab_geo, tab_cust, tab_profit, tab_corr = st.tabs([
                "📈 Sales Trends", "📦 Product & Category", "🌎 Regional Analysis", "👥 Customer Insights", "💵 Profits & Margins", "🧬 Correlations"
            ])
            
            with tab_sales:
                st.markdown("#### Historical Sales timelines")
                trend_group = st.selectbox("Group sales timeline by:", ["Day", "Week", "Month"], index=2)
                st.plotly_chart(plot_sales_trend(filtered_df, group_by=trend_group), use_container_width=True)
                
                # Period bar chart
                period_group = st.selectbox("Compare aggregated sales by:", ["Year", "Quarter", "Month"], index=2)
                st.plotly_chart(plot_sales_by_period(filtered_df, period=period_group), use_container_width=True)
                
            with tab_prod:
                st.markdown("#### Product Metrics")
                best_worst_col1, best_worst_col2 = st.columns(2)
                with best_worst_col1:
                    st.plotly_chart(plot_product_analysis(filtered_df, top_n=10, ascending=False), use_container_width=True)
                with best_worst_col2:
                    st.plotly_chart(plot_product_analysis(filtered_df, top_n=10, ascending=True), use_container_width=True)
                    
            with tab_geo:
                st.markdown("#### Geographic Performance")
                geo_col1, geo_col2 = st.columns(2)
                with geo_col1:
                    st.plotly_chart(plot_regional_analysis(filtered_df, metric="Sales"), use_container_width=True)
                with geo_col2:
                    st.plotly_chart(plot_regional_analysis(filtered_df, metric="Profit"), use_container_width=True)
                    
            with tab_cust:
                st.markdown("#### Customer Volume & Recurrence")
                cust_col1, cust_col2 = st.columns(2)
                with cust_col1:
                    st.plotly_chart(plot_customer_analysis(filtered_df, top_n=10), use_container_width=True)
                with cust_col2:
                    st.plotly_chart(plot_repeat_customers(filtered_df), use_container_width=True)
                    
            with tab_profit:
                st.markdown("#### Financial Yields")
                st.plotly_chart(plot_profit_analysis(filtered_df), use_container_width=True)
                st.plotly_chart(plot_sales_vs_profit_scatter(filtered_df), use_container_width=True)
                
            with tab_corr:
                st.markdown("#### Correlation Matrix")
                st.plotly_chart(plot_correlation_heatmap(filtered_df), use_container_width=True)

# ----------------- PAGE 5: MODEL TRAINING -----------------
elif page == "🤖 Model Training":
    st.title("🤖 Predictive Machine Learning Models")
    st.write("Train supervised regressors on lag and rolling features to predict future Monthly Sales.")
    
    if st.session_state.cleaned_df is None:
        st.warning("⚠️ No dataset has been loaded. Please go to the **📂 Dataset** page.")
    else:
        monthly_data = st.session_state.monthly_df
        
        # Display monthly aggregated dataframe size
        st.write(f"Aggregated monthly training dataset: **{len(monthly_data)} historical months** available.")
        
        st.markdown('<div class="section-header">Train Configuration</div>', unsafe_allow_html=True)
        col1, col2 = st.columns(2)
        with col1:
            test_months = st.slider("Validation Set Size (Holdout Months)", min_value=3, max_value=24, value=12)
        with col2:
            st.write("")
            st.write("")
            tune_params = st.checkbox("Perform Hyperparameter Tuning (GridSearchCV + CV=3)", value=False, help="Will perform grid search on Random Forest and XGBoost. May take a few seconds.")
            
        if st.button("🚀 Train Regression Models", use_container_width=True):
            with st.spinner("Preparing features and training models..."):
                # Split features
                X_train, X_test, y_train, y_test, dates_train, dates_test, features = prepare_train_test_split(
                    monthly_data, test_months=test_months
                )
                
                # Train & Evaluate
                metrics, models, predictions, importances, best_model = train_and_evaluate_models(
                    X_train, X_test, y_train, y_test, tune_hyperparameters=tune_params
                )
                
                # Store in session state
                st.session_state.has_trained = True
                st.session_state.model_metrics = metrics
                st.session_state.best_ml_model = best_model
                st.session_state.trained_models = models
                st.session_state.ml_predictions = predictions
                st.session_state.ml_importances = importances
                st.session_state.ml_features = features
                
                st.success("✅ Models trained and validated successfully!")
                
        if st.session_state.has_trained:
            # Display metrics comparison
            st.markdown('<div class="section-header">Model Performance Metrics Comparison</div>', unsafe_allow_html=True)
            st.dataframe(st.session_state.model_metrics, use_container_width=True)
            
            best_model_name = st.session_state.best_ml_model
            st.success(f"🏆 **Best Performing Model**: {best_model_name} (Lowest RMSE)")
            
            # Show feature importance & residuals
            st.markdown('<div class="section-header">Diagnostics & Interpretability</div>', unsafe_allow_html=True)
            
            diag_col1, diag_col2 = st.columns(2)
            
            with diag_col1:
                # Plot Feature Importance
                if best_model_name in st.session_state.ml_importances:
                    imp_vals = st.session_state.ml_importances[best_model_name]
                    df_imp = pd.DataFrame({
                        "Feature": st.session_state.ml_features,
                        "Importance": imp_vals
                    }).sort_values("Importance", ascending=False)
                    
                    fig_imp = px.bar(
                        df_imp, x="Importance", y="Feature", orientation="h",
                        title=f"{best_model_name} Feature Importances",
                        template="plotly_white"
                    )
                    fig_imp.update_layout(yaxis={'categoryorder':'total ascending'})
                    st.plotly_chart(fig_imp, use_container_width=True)
                else:
                    st.write("Feature importance not available for this model.")
                    
            with diag_col2:
                # Residual plot for test set
                # Residual = y_test - y_pred
                X_train, X_test, y_train, y_test, dates_train, dates_test, features = prepare_train_test_split(
                    monthly_data, test_months=test_months
                )
                y_pred = st.session_state.ml_predictions[best_model_name]
                residuals = y_test - y_pred
                
                df_res = pd.DataFrame({
                    "Actual Sales": y_test,
                    "Residuals": residuals,
                    "Month": dates_test.dt.strftime("%Y-%b")
                })
                
                fig_res = px.scatter(
                    df_res, x="Actual Sales", y="Residuals", hover_data=["Month"],
                    title=f"Residual Plot (Best Model: {best_model_name})",
                    template="plotly_white"
                )
                fig_res.add_hline(y=0, line_dash="dash", line_color="red")
                st.plotly_chart(fig_res, use_container_width=True)

# ----------------- PAGE 6: FORECAST -----------------
elif page == "📈 Forecast":
    st.title("📈 Time Series Forecasting Dashboard")
    st.write("Generate and visualize next 12-month future sales demand with statistical confidence intervals.")
    
    if st.session_state.cleaned_df is None:
        st.warning("⚠️ No dataset has been loaded. Please go to the **📂 Dataset** page.")
    else:
        monthly_data = st.session_state.monthly_df
        
        st.markdown('<div class="section-header">Generate Predictions</div>', unsafe_allow_html=True)
        
        forecast_horizon = st.slider("Forecast Horizon (Months ahead)", min_value=6, max_value=24, value=12)
        
        if st.button("🎯 Generate Time Series Forecasts", use_container_width=True):
            with st.spinner("Generating statistical forecasts..."):
                # Run validation to get comparisons
                ts_perf, ts_res = train_and_evaluate_time_series(monthly_data, forecast_months=12)
                st.session_state.ts_metrics = ts_perf
                
                # Generate actual future forecasts
                forecasts = generate_future_forecasts(monthly_data, steps=forecast_horizon)
                st.session_state.ts_forecasts = forecasts
                
                # Pick the best model automatically based on RMSE validation
                # The model names could be 'ARIMA', 'Exponential Smoothing', 'Prophet' / 'Prophet (Fallback: Seasonal Reg)'
                valid_models = [m for m in ts_perf.index if ts_perf.loc[m, "RMSE"] != "N/A"]
                if valid_models:
                    # Get index of lowest RMSE
                    rmse_vals = pd.to_numeric(ts_perf.loc[valid_models, "RMSE"])
                    st.session_state.selected_ts_model = rmse_vals.idxmin()
                else:
                    st.session_state.selected_ts_model = list(forecasts.keys())[0]
                    
                st.success("✅ Time series models trained and future forecasts compiled!")
                
        if st.session_state.ts_forecasts is not None:
            # Model Validation Table
            st.markdown('<div class="section-header">Time Series Holdout Validation Metrics (Last 12 Months)</div>', unsafe_allow_html=True)
            st.dataframe(st.session_state.ts_metrics, use_container_width=True)
            
            # Select forecasting model
            st.markdown('<div class="section-header">Future Forecast Visualizer</div>', unsafe_allow_html=True)
            
            all_forecast_models = list(st.session_state.ts_forecasts.keys())
            
            # Default to best model
            best_idx = 0
            if st.session_state.selected_ts_model in all_forecast_models:
                best_idx = all_forecast_models.index(st.session_state.selected_ts_model)
                
            selected_model = st.selectbox("Select model for forecast projection", all_forecast_models, index=best_idx)
            st.session_state.selected_ts_model = selected_model
            
            # Retrieve selected forecast
            f_df = st.session_state.ts_forecasts[selected_model]
            
            # Plot historical vs future
            df_hist = monthly_data[["Order Date", "Sales"]].copy()
            df_hist["Type"] = "Historical"
            
            df_fut = f_df[["Order Date", "Sales"]].copy()
            df_fut["Type"] = "Forecast"
            
            # Create Plotly figure with confidence bands
            fig = go.Figure()
            
            # Historical line
            fig.add_trace(go.Scatter(
                x=df_hist["Order Date"], y=df_hist["Sales"],
                mode="lines", name="Historical Sales",
                line=dict(color="#1F77B4", width=3)
            ))
            
            # Forecast line
            fig.add_trace(go.Scatter(
                x=df_fut["Order Date"], y=df_fut["Sales"],
                mode="lines+markers", name=f"Forecasted Sales ({selected_model})",
                line=dict(color="#2CA02C", width=3, dash="dash")
            ))
            
            # Confidence interval bounds (shaded area)
            fig.add_trace(go.Scatter(
                x=f_df["Order Date"].tolist() + f_df["Order Date"].tolist()[::-1],
                y=f_df["Upper Bound"].tolist() + f_df["Lower Bound"].tolist()[::-1],
                fill="toself",
                fillcolor="rgba(44, 160, 44, 0.15)",
                line=dict(color="rgba(255,255,255,0)"),
                hoverinfo="skip",
                showlegend=True,
                name="95% Confidence Interval"
            ))
            
            fig.update_layout(
                title=f"Future Demand Projection: Historical vs Forecast ({selected_model})",
                xaxis_title="Date",
                yaxis_title="Monthly Sales ($)",
                template="plotly_white",
                hovermode="x unified"
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Forecast values table preview
            st.markdown(f"#### Forecast Table ({selected_model})")
            st.dataframe(
                f_df.rename(columns={"Sales": "Point Forecast ($)", "Lower Bound": "Lower Interval ($)", "Upper Bound": "Upper Interval ($)"}),
                use_container_width=True
            )

# ----------------- PAGE 7: REPORTS -----------------
elif page == "📄 Reports":
    st.title("📄 Executive Reports & Data Export")
    st.write("Export predicting results, download the cleaned transactional ledger, or compile the PDF executive forecast.")
    
    if st.session_state.cleaned_df is None:
        st.warning("⚠️ No dataset has been loaded. Please go to the **📂 Dataset** page.")
    else:
        cleaned_df = st.session_state.cleaned_df
        monthly_df = st.session_state.monthly_df
        
        st.markdown('<div class="section-header">Download Datasets & Preds</div>', unsafe_allow_html=True)
        
        exp_col1, exp_col2 = st.columns(2)
        
        with exp_col1:
            csv_clean = io.StringIO()
            cleaned_df.to_csv(csv_clean, index=False)
            st.download_button(
                label="💾 Download Cleaned Transactions (CSV)",
                data=csv_clean.getvalue(),
                file_name="cleaned_sales_data.csv",
                mime="text/csv",
                use_container_width=True
            )
            
        with exp_col2:
            if st.session_state.ts_forecasts is not None and st.session_state.selected_ts_model is not None:
                model_name = st.session_state.selected_ts_model
                forecast_df = st.session_state.ts_forecasts[model_name]
                
                csv_pred = io.StringIO()
                forecast_df.to_csv(csv_pred, index=False)
                st.download_button(
                    label=f"💾 Export {model_name} Forecast Table (CSV)",
                    data=csv_pred.getvalue(),
                    file_name=f"sales_forecast_{model_name.lower().replace(' ', '_')}.csv",
                    mime="text/csv",
                    use_container_width=True
                )
            else:
                st.info("⚠️ Please generate a forecast projection on the **📈 Forecast** page first to export predictions.")
                
        st.markdown('<div class="section-header">Generate Executive PDF Report</div>', unsafe_allow_html=True)
        st.write("Compile a multi-page, formatted PDF containing KPIs, cleaning stats, model comparisons, and point predictions.")
        
        if st.session_state.ts_forecasts is not None and st.session_state.selected_ts_model is not None:
            # Ready to generate PDF
            kpis = compute_kpis(cleaned_df)
            
            # Attach best model evaluations
            # Combine ML and TS evaluation stats into a unified table
            ml_m = st.session_state.model_metrics.copy() if st.session_state.model_metrics is not None else pd.DataFrame()
            ts_m = st.session_state.ts_metrics.copy() if st.session_state.ts_metrics is not None else pd.DataFrame()
            
            # Combine
            combined_metrics = pd.concat([ml_m, ts_m])
            
            # Best model is determined from RMSE
            valid_rows = combined_metrics[combined_metrics["RMSE"] != "N/A"]
            if not valid_rows.empty:
                rmse_vals = pd.to_numeric(valid_rows["RMSE"])
                best_overall = rmse_vals.idxmin()
            else:
                best_overall = st.session_state.selected_ts_model
                
            kpis["best_model"] = best_overall
            
            # Build cleaning summary details
            summary_info = st.session_state.cleaning_summary
            
            # Generate PDF bytes
            with st.spinner("Generating PDF report..."):
                selected_model_name = st.session_state.selected_ts_model
                forecast_pdf_df = st.session_state.ts_forecasts[selected_model_name]
                
                pdf_data = generate_pdf_report(
                    summary_info,
                    kpis,
                    combined_metrics,
                    forecast_pdf_df
                )
                
                st.download_button(
                    label="📄 Download Executive PDF Forecast Report",
                    data=pdf_data,
                    file_name="executive_sales_forecast_report.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )
        else:
            st.info("⚠️ Make sure to run both **🤖 Model Training** and **📈 Forecast** pages to compile the final PDF executive report.")
