import pandas as pd
import numpy as np
import datetime
import os

# Set random seed for reproducibility
np.random.seed(42)

# Configuration
start_date = datetime.date(2021, 1, 1)
end_date = datetime.date(2026, 6, 30)
num_days = (end_date - start_date).days + 1

categories_products = {
    "Technology": {
        "products": ["Pro Laptop 15", "Smart Phone X", "Noise Cancelling Headphones", "UltraWide 34 Monitor", "Wireless Charging Pad"],
        "base_prices": [1200.00, 800.00, 250.00, 450.00, 49.99],
        "margins": [0.25, 0.30, 0.40, 0.28, 0.50]
    },
    "Furniture": {
        "products": ["Ergonomic Office Chair", "Standing Desk", "3-Shelf Bookshelf", "L-Shaped Sofa", "Minimalist Coffee Table"],
        "base_prices": [350.00, 600.00, 120.00, 950.00, 180.00],
        "margins": [0.22, 0.20, 0.25, 0.15, 0.28]
    },
    "Office Supplies": {
        "products": ["Premium Paper Ream", "Heavy Duty Binder", "Gel Pen Assortment (12-pack)", "Classic Hardcover Journal", "Desktop Organizer"],
        "base_prices": [12.50, 18.00, 15.00, 22.00, 35.00],
        "margins": [0.60, 0.55, 0.65, 0.50, 0.45]
    }
}

regions = ["East", "West", "Central", "South", "North"]
region_weights = [0.30, 0.35, 0.18, 0.12, 0.05]

customers = [
    "Acme Corporation", "Global Industries", "Tech Solutions Inc", "Apex Retail",
    "Starlight Ventures", "Beacon Enterprises", "Quantum Labs", "Summit Partners",
    "Horizon Logistics", "Pinnacle Holdings", "Alice Johnson", "Bob Smith",
    "Charlie Brown", "David Miller", "Emily Davis", "Frank Wilson",
    "Grace Lee", "Henry Taylor", "Ivy Clark", "Jack Harris"
]

# Generate transactions
data = []
current_date = start_date

while current_date <= end_date:
    # Determine number of transactions for this day
    day_of_week = current_date.weekday() # 0 = Monday, 6 = Sunday
    month = current_date.month
    year = current_date.year
    
    # Seasonality factor (peaks in Nov/Dec, smaller peak in June/July)
    seasonality = 1.0
    if month in [11, 12]:
        seasonality = 1.4
    elif month in [6, 7]:
        seasonality = 1.15
        
    # Weekly variation (less sales on weekends)
    day_factor = 1.0 if day_of_week < 5 else 0.5
    
    # Growth trend over time (growing 7% per year starting from 2021)
    years_since_start = (current_date - start_date).days / 365.25
    trend = 1.0 + (0.07 * years_since_start)
    
    # Daily transaction count (random Poisson distribution)
    avg_transactions = 4 * seasonality * day_factor * trend
    num_tx = np.random.poisson(avg_transactions)
    num_tx = max(1, num_tx) # Ensure at least one transaction per day
    
    for _ in range(num_tx):
        category = np.random.choice(list(categories_products.keys()))
        prod_info = categories_products[category]
        idx = np.random.randint(len(prod_info["products"]))
        
        product = prod_info["products"][idx]
        base_price = prod_info["base_prices"][idx]
        margin = prod_info["margins"][idx]
        
        # Quantity purchased
        quantity = np.random.choice([1, 2, 3, 4, 5, 10], p=[0.50, 0.25, 0.12, 0.08, 0.04, 0.01])
        
        # Unit Price variation (small random fluctuation)
        unit_price = round(base_price * np.random.uniform(0.95, 1.05), 2)
        
        # Discount
        discount = np.random.choice([0.0, 0.05, 0.10, 0.15, 0.20, 0.30], p=[0.70, 0.10, 0.08, 0.06, 0.04, 0.02])
        
        # Sales calculation
        sales = round(quantity * unit_price * (1 - discount), 2)
        
        # Profit calculation
        actual_margin = margin + np.random.uniform(-0.03, 0.03)
        profit = round(sales * actual_margin, 2)
        
        region = np.random.choice(regions, p=region_weights)
        customer = np.random.choice(customers)
        
        data.append({
            "Order Date": current_date.strftime("%Y-%m-%d"),
            "Product": product,
            "Category": category,
            "Customer": customer,
            "Region": region,
            "Quantity": int(quantity),
            "Unit Price": float(unit_price),
            "Discount": float(discount),
            "Sales": float(sales),
            "Profit": float(profit)
        })
        
    current_date += datetime.timedelta(days=1)

df = pd.DataFrame(data)

# Create the workspace directories if they don't exist
os.makedirs("data", exist_ok=True)
df.to_csv("data/sample_sales_data.csv", index=False)
print(f"Generated dataset with {len(df)} records.")
print(f"Saved to data/sample_sales_data.csv")
