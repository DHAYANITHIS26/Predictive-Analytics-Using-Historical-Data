import pandas as pd
import numpy as np
import os

REQUIRED_COLUMNS = [
    "Order Date", "Product", "Category", "Customer", 
    "Region", "Quantity", "Unit Price", "Discount", 
    "Sales", "Profit"
]

def load_data(file):
    """
    Loads data from a file-like object (or path) which can be CSV or Excel.
    """
    _, file_extension = os.path.splitext(getattr(file, "name", str(file)))
    if file_extension.lower() in [".xlsx", ".xls"]:
        return pd.read_excel(file)
    else:
        return pd.read_csv(file)

def validate_schema(df):
    """
    Checks if all required columns are present.
    Returns (is_valid, missing_columns)
    """
    df_cols = [col.strip() for col in df.columns]
    missing = [col for col in REQUIRED_COLUMNS if col not in df_cols]
    return len(missing) == 0, missing

def clean_data(df):
    """
    Performs data cleaning:
    1. Removes duplicates
    2. Handles missing values
    3. Standardizes date formats
    4. Removes invalid records (Quantity <= 0, Unit Price <= 0, Sales <= 0)
    5. Handles outliers by clipping at the 99th percentile
    6. Normalizes categorical strings
    """
    # Create a copy
    cleaned = df.copy()
    
    # Strip whitespace from column names
    cleaned.columns = [col.strip() for col in cleaned.columns]
    
    # 1. Remove duplicates
    cleaned = cleaned.drop_duplicates()
    
    # 2. Convert Order Date to datetime
    cleaned["Order Date"] = pd.to_datetime(cleaned["Order Date"], errors="coerce")
    cleaned = cleaned.dropna(subset=["Order Date"])
    
    # 3. Handle missing values
    # Numeric columns
    num_cols = ["Quantity", "Unit Price", "Discount", "Sales", "Profit"]
    for col in num_cols:
        if col in cleaned.columns:
            cleaned[col] = pd.to_numeric(cleaned[col], errors="coerce")
            median_val = cleaned[col].median()
            # If median is NaN (empty column), fill with 0
            cleaned[col] = cleaned[col].fillna(median_val if not pd.isna(median_val) else 0.0)
            
    # Categorical columns
    cat_cols = ["Product", "Category", "Customer", "Region"]
    for col in cat_cols:
        if col in cleaned.columns:
            cleaned[col] = cleaned[col].astype(str).str.strip()
            cleaned[col] = cleaned[col].fillna("Unknown")
            
    # 4. Remove invalid records
    if "Quantity" in cleaned.columns:
        cleaned = cleaned[cleaned["Quantity"] > 0]
    if "Unit Price" in cleaned.columns:
        cleaned = cleaned[cleaned["Unit Price"] > 0]
    if "Sales" in cleaned.columns:
        cleaned = cleaned[cleaned["Sales"] > 0]
        
    # 5. Handle outliers by clipping at 99th percentile for Quantity and Unit Price
    for col in ["Quantity", "Unit Price", "Sales"]:
        if col in cleaned.columns:
            q_99 = cleaned[col].quantile(0.99)
            cleaned[col] = cleaned[col].clip(upper=q_99)
            
    # Recalculate Profit Margin if possible
    # (Sales - Cost) / Sales. If Profit is given, check consistency:
    # We will preserve Profit, but make sure it is a float.
    cleaned["Profit"] = cleaned["Profit"].astype(float)
    cleaned["Sales"] = cleaned["Sales"].astype(float)
    cleaned["Quantity"] = cleaned["Quantity"].astype(int)
    cleaned["Unit Price"] = cleaned["Unit Price"].astype(float)
    cleaned["Discount"] = cleaned["Discount"].astype(float)

    # 6. Feature Engineering - Date Parts
    cleaned["Year"] = cleaned["Order Date"].dt.year
    cleaned["Month"] = cleaned["Order Date"].dt.month
    cleaned["Quarter"] = cleaned["Order Date"].dt.quarter
    # use isocalendar for week to avoid deprecation warnings
    cleaned["Week"] = cleaned["Order Date"].dt.isocalendar().week.astype(int)
    cleaned["Day"] = cleaned["Order Date"].dt.day
    cleaned["Day of Week"] = cleaned["Order Date"].dt.dayofweek # 0 = Monday, 6 = Sunday
    cleaned["Day Name"] = cleaned["Order Date"].dt.day_name()
    
    return cleaned

def prepare_monthly_data(df):
    """
    Aggregates transactional sales data to a monthly level and generates lag,
    rolling, and seasonal features suitable for ML models.
    """
    # Ensure cleaned data
    cleaned = df.copy()
    cleaned["Order Date"] = pd.to_datetime(cleaned["Order Date"])
    
    # Set Order Date as index for resampling
    monthly = cleaned.set_index("Order Date").resample("ME").agg({
        "Sales": "sum",
        "Profit": "sum",
        "Quantity": "sum",
        "Discount": "mean"
    }).reset_index()
    
    # Extract date parts
    monthly["Year"] = monthly["Order Date"].dt.year
    monthly["Month"] = monthly["Order Date"].dt.month
    
    # 1. Lag Features (1, 2, 3, and 12 months lag)
    for lag in [1, 2, 3, 12]:
        monthly[f"Sales_Lag_{lag}"] = monthly["Sales"].shift(lag)
        monthly[f"Profit_Lag_{lag}"] = monthly["Profit"].shift(lag)
        
    # 2. Rolling Averages (3-month and 6-month)
    monthly["Sales_Rolling_Mean_3"] = monthly["Sales"].shift(1).rolling(window=3).mean()
    monthly["Sales_Rolling_Mean_6"] = monthly["Sales"].shift(1).rolling(window=6).mean()
    
    # 3. Growth Rate (Month over Month)
    monthly["Sales_Growth_1m"] = monthly["Sales"].pct_change(1) * 100
    monthly["Sales_Growth_1m"] = monthly["Sales_Growth_1m"].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    
    # 4. Seasonal Features
    # Nov/Dec peak indicators
    monthly["Is_Holiday_Season"] = monthly["Month"].isin([11, 12]).astype(int)
    # Q4 indicator
    monthly["Is_Q4"] = (monthly["Month"] >= 10).astype(int)
    
    # Cyclical encoding of month (to capture continuity from December to January)
    monthly["Month_Sin"] = np.sin(2 * np.pi * monthly["Month"] / 12.0)
    monthly["Month_Cos"] = np.cos(2 * np.pi * monthly["Month"] / 12.0)
    
    # Fill any NaNs created by lag and rolling operations with historical median/mean values or backfills
    # For ML models, we'll drop the rows that contain NaNs (specifically lag 12 needs 12 months of history)
    # So we only train on rows where we have lags
    return monthly
