import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# We will use 'plotly_white' as the base theme for a premium look, which integrates well with Streamlit.
THEME = "plotly_white"

def plot_sales_trend(df, group_by="Month"):
    """
    Plots the Sales Trend over time.
    Supports Grouping by 'Day', 'Week', or 'Month'.
    """
    df_plot = df.copy()
    if group_by == "Day":
        df_grouped = df_plot.groupby("Order Date")["Sales"].sum().reset_index()
        x_col = "Order Date"
    elif group_by == "Week":
        # Group by Year and Week
        df_grouped = df_plot.groupby(["Year", "Week"])["Sales"].sum().reset_index()
        df_grouped["Date"] = df_grouped.apply(lambda r: pd.to_datetime(f"{int(r['Year'])}-W{int(r['Week'])}-1", format="%Y-W%W-%w", errors="coerce"), axis=1)
        df_grouped = df_grouped.dropna(subset=["Date"]).sort_values("Date")
        x_col = "Date"
    else: # Month
        df_grouped = df_plot.groupby(["Year", "Month"])["Sales"].sum().reset_index()
        df_grouped["Date"] = pd.to_datetime(df_grouped.apply(lambda r: f"{int(r['Year'])}-{int(r['Month'])}-01", axis=1))
        df_grouped = df_grouped.sort_values("Date")
        x_col = "Date"

    fig = px.area(
        df_grouped, 
        x=x_col, 
        y="Sales", 
        title=f"Overall Sales Trend (Grouped by {group_by})",
        labels={x_col: "Date", "Sales": "Sales ($)"},
        template=THEME
    )
    fig.update_traces(line_color="#1F77B4", fillcolor="rgba(31, 119, 180, 0.2)")
    fig.update_layout(
        hovermode="x unified",
        xaxis=dict(showgrid=True, gridcolor="rgba(200, 200, 200, 0.2)"),
        yaxis=dict(showgrid=True, gridcolor="rgba(200, 200, 200, 0.2)")
    )
    return fig

def plot_sales_by_period(df, period="Month"):
    """
    Plots Sales by Period (Yearly, Quarterly, Monthly).
    """
    df_plot = df.copy()
    if period == "Year":
        df_grouped = df_plot.groupby("Year")["Sales"].sum().reset_index()
        df_grouped["Year"] = df_grouped["Year"].astype(str)
        fig = px.bar(
            df_grouped, x="Year", y="Sales", 
            title="Total Sales by Year", 
            labels={"Sales": "Sales ($)", "Year": "Year"},
            text_auto=".2s", template=THEME
        )
    elif period == "Quarter":
        df_grouped = df_plot.groupby(["Year", "Quarter"])["Sales"].sum().reset_index()
        df_grouped["Quarter_Str"] = df_grouped.apply(lambda r: f"{int(r['Year'])} Q{int(r['Quarter'])}", axis=1)
        fig = px.bar(
            df_grouped, x="Quarter_Str", y="Sales", 
            title="Total Sales by Quarter", 
            labels={"Sales": "Sales ($)", "Quarter_Str": "Quarter"},
            text_auto=".2s", template=THEME
        )
    else: # Month
        # Average/Total Sales by Month (seasonal view)
        df_grouped = df_plot.groupby("Month")["Sales"].mean().reset_index()
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        df_grouped["Month Name"] = df_grouped["Month"].apply(lambda m: month_names[m-1])
        fig = px.bar(
            df_grouped, x="Month Name", y="Sales", 
            title="Average Sales by Month (Seasonality Analysis)", 
            labels={"Sales": "Average Sales ($)", "Month Name": "Month"},
            text_auto=".2s", template=THEME
        )

    fig.update_traces(marker_color="#2CA02C")
    fig.update_layout(xaxis=dict(showgrid=False), yaxis=dict(showgrid=True, gridcolor="rgba(200, 200, 200, 0.2)"))
    return fig

def plot_product_analysis(df, top_n=10, ascending=False):
    """
    Plots top or worst selling products.
    """
    df_grouped = df.groupby(["Product", "Category"])["Sales"].sum().reset_index()
    df_sorted = df_grouped.sort_values(by="Sales", ascending=ascending).head(top_n)
    
    title = f"Top {top_n} Best Selling Products" if not ascending else f"Top {top_n} Worst Selling Products"
    
    fig = px.bar(
        df_sorted, 
        y="Product", 
        x="Sales", 
        color="Category",
        orientation="h",
        title=title,
        labels={"Sales": "Total Sales ($)", "Product": "Product Name"},
        template=THEME,
        color_discrete_sequence=px.colors.qualitative.Pastel
    )
    fig.update_layout(yaxis={'categoryorder':'total ' + ('ascending' if ascending else 'descending')})
    return fig

def plot_regional_analysis(df, metric="Sales"):
    """
    Plots regional contribution using Pie (for Share) and Bar charts (for comparison).
    """
    df_grouped = df.groupby("Region")[[metric, "Profit"]].sum().reset_index()
    
    fig_pie = px.pie(
        df_grouped, 
        values=metric, 
        names="Region", 
        title=f"Regional Contribution ({metric})",
        template=THEME,
        hole=0.4,
        color_discrete_sequence=px.colors.qualitative.Safe
    )
    
    # Customize layout to look professional
    fig_pie.update_traces(textposition="inside", textinfo="percent+label")
    return fig_pie

def plot_customer_analysis(df, top_n=10):
    """
    Plots Top Customers by Sales and Profit.
    """
    df_cust = df.groupby("Customer").agg({
        "Sales": "sum",
        "Profit": "sum",
        "Quantity": "count" # Orders count
    }).reset_index()
    
    df_top_sales = df_cust.sort_values(by="Sales", ascending=False).head(top_n)
    
    fig = px.bar(
        df_top_sales,
        x="Sales",
        y="Customer",
        title=f"Top {top_n} Customers by Total Revenue",
        labels={"Sales": "Revenue ($)", "Customer": "Customer"},
        orientation="h",
        template=THEME,
        text_auto=".2s"
    )
    fig.update_traces(marker_color="#9467BD")
    fig.update_layout(yaxis={'categoryorder':'total ascending'})
    return fig

def plot_repeat_customers(df):
    """
    Visualizes distribution of transaction counts per customer to show repeat behavior.
    """
    df_grouped = df.groupby("Customer")["Order Date"].count().reset_index()
    df_grouped.columns = ["Customer", "Transaction Count"]
    
    fig = px.histogram(
        df_grouped,
        x="Transaction Count",
        title="Customer Purchase Frequency (Repeat Customers)",
        labels={"Transaction Count": "Number of Purchases", "count": "Number of Customers"},
        template=THEME,
        nbins=20
    )
    fig.update_traces(marker_color="#FF7F0E")
    fig.update_layout(bargap=0.05)
    return fig

def plot_profit_analysis(df):
    """
    Plots Monthly Profit and Monthly Profit Margin (Line chart + secondary axis / subplot)
    """
    df_plot = df.copy()
    df_grouped = df_plot.groupby(["Year", "Month"]).agg({
        "Sales": "sum",
        "Profit": "sum"
    }).reset_index()
    
    df_grouped["Date"] = pd.to_datetime(df_grouped.apply(lambda r: f"{int(r['Year'])}-{int(r['Month'])}-01", axis=1))
    df_grouped = df_grouped.sort_values("Date")
    df_grouped["Profit Margin %"] = (df_grouped["Profit"] / df_grouped["Sales"]) * 100
    
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    
    # Monthly Profit Line
    fig.add_trace(
        go.Scatter(
            x=df_grouped["Date"], 
            y=df_grouped["Profit"], 
            name="Profit ($)", 
            mode="lines+markers",
            line=dict(color="#2CA02C", width=3)
        ),
        secondary_y=False
    )
    
    # Profit Margin Line
    fig.add_trace(
        go.Scatter(
            x=df_grouped["Date"], 
            y=df_grouped["Profit Margin %"], 
            name="Profit Margin %", 
            mode="lines+markers",
            line=dict(color="#D62728", width=2, dash="dash")
        ),
        secondary_y=True
    )
    
    fig.update_layout(
        title_text="Monthly Net Profit & Profit Margin Trend",
        template=THEME,
        hovermode="x unified"
    )
    
    fig.update_xaxes(title_text="Date")
    fig.update_yaxes(title_text="Profit ($)", secondary_y=False)
    fig.update_yaxes(title_text="Profit Margin (%)", secondary_y=True, range=[0, 100])
    
    return fig

def plot_correlation_heatmap(df):
    """
    Plots a Heatmap of Pearson correlations between key numerical metrics and engineered dates.
    """
    cols = ["Quantity", "Unit Price", "Discount", "Sales", "Profit", "Year", "Month", "Day of Week"]
    # Filter columns that are present in the dataframe
    avail_cols = [c for c in cols if c in df.columns]
    
    corr = df[avail_cols].corr()
    
    # Plot using Plotly Heatmap
    fig = px.imshow(
        corr,
        text_auto=".2f",
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-1,
        zmax=1,
        title="Feature Correlation Heatmap",
        template=THEME
    )
    
    return fig

def plot_sales_vs_profit_scatter(df):
    """
    Plots a Scatter plot of Sales vs Profit by Category.
    """
    # Sample down if too large for fluid Plotly rendering
    sample_df = df
    if len(df) > 5000:
        sample_df = df.sample(n=5000, random_state=42)
        
    fig = px.scatter(
        sample_df,
        x="Sales",
        y="Profit",
        color="Category",
        hover_data=["Product"],
        title="Sales vs. Profit Scatter Analysis (Sampled to max 5,000 tx)",
        labels={"Sales": "Sales ($)", "Profit": "Profit ($)"},
        template=THEME
    )
    return fig

