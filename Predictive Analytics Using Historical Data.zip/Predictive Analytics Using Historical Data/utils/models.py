import pandas as pd
import numpy as np
from sklearn.model_selection import TimeSeriesSplit, GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings

# Try to import xgboost; fall back gracefully if not installed
try:
    import xgboost as xgb
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False

def calculate_mape(y_true, y_pred):
    """
    Calculates Mean Absolute Percentage Error.
    """
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    # Avoid division by zero
    mask = y_true != 0
    if not np.any(mask):
        return 0.0
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100

def prepare_train_test_split(monthly_df, test_months=12):
    """
    Prepares features and target, and splits into train and test sets based on time.
    """
    # Drop rows with NaNs (specifically lag 12 needs first 12 rows to be NaN)
    df_clean = monthly_df.dropna().copy()
    
    if len(df_clean) <= test_months + 3:
        # Fallback if dataset is too small
        test_months = max(1, len(df_clean) // 5)
        
    features = [
        "Year", "Month", "Sales_Lag_1", "Sales_Lag_2", "Sales_Lag_3", "Sales_Lag_12",
        "Sales_Rolling_Mean_3", "Sales_Rolling_Mean_6", 
        "Is_Holiday_Season", "Is_Q4", "Month_Sin", "Month_Cos"
    ]
    
    X = df_clean[features]
    y = df_clean["Sales"]
    dates = df_clean["Order Date"]
    
    # Train-test split (time-based)
    split_idx = len(df_clean) - test_months
    
    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
    dates_train, dates_test = dates.iloc[:split_idx], dates.iloc[split_idx:]
    
    return X_train, X_test, y_train, y_test, dates_train, dates_test, features

def train_and_evaluate_models(X_train, X_test, y_train, y_test, tune_hyperparameters=False):
    """
    Trains Linear Regression, Random Forest, and XGBoost.
    Evaluates on test set and returns performance metrics, models, predictions,
    and feature importances.
    """
    results = {}
    predictions = {}
    models = {}
    importances = {}
    
    # --- 1. Linear Regression ---
    lr = LinearRegression()
    lr.fit(X_train, y_train)
    lr_pred = lr.predict(X_test)
    
    models["Linear Regression"] = lr
    predictions["Linear Regression"] = lr_pred
    # Coefficients as importances
    importances["Linear Regression"] = np.abs(lr.coef_)
    
    # --- 2. Random Forest Regressor ---
    if tune_hyperparameters and len(X_train) > 10:
        rf_grid = {
            "n_estimators": [50, 100],
            "max_depth": [4, 6, None],
            "min_samples_split": [2, 5]
        }
        tscv = TimeSeriesSplit(n_splits=3)
        rf_base = RandomForestRegressor(random_state=42)
        grid_search = GridSearchCV(estimator=rf_base, param_grid=rf_grid, cv=tscv, scoring="neg_mean_squared_error", n_jobs=-1)
        grid_search.fit(X_train, y_train)
        rf = grid_search.best_estimator_
    else:
        rf = RandomForestRegressor(n_estimators=100, max_depth=6, random_state=42)
        rf.fit(X_train, y_train)
        
    rf_pred = rf.predict(X_test)
    models["Random Forest"] = rf
    predictions["Random Forest"] = rf_pred
    importances["Random Forest"] = rf.feature_importances_
    
    # --- 3. XGBoost Regressor ---
    xgb_trained = False
    if XGB_AVAILABLE:
        try:
            if tune_hyperparameters and len(X_train) > 10:
                xgb_grid = {
                    "n_estimators": [50, 100],
                    "max_depth": [3, 5, 7],
                    "learning_rate": [0.05, 0.1, 0.2]
                }
                tscv = TimeSeriesSplit(n_splits=3)
                xgb_base = xgb.XGBRegressor(random_state=42)
                grid_search_xgb = GridSearchCV(estimator=xgb_base, param_grid=xgb_grid, cv=tscv, scoring="neg_mean_squared_error", n_jobs=-1)
                grid_search_xgb.fit(X_train, y_train)
                xgb_model = grid_search_xgb.best_estimator_
            else:
                xgb_model = xgb.XGBRegressor(n_estimators=100, max_depth=5, learning_rate=0.1, random_state=42)
                xgb_model.fit(X_train, y_train)
                
            xgb_pred = xgb_model.predict(X_test)
            models["XGBoost"] = xgb_model
            predictions["XGBoost"] = xgb_pred
            importances["XGBoost"] = xgb_model.feature_importances_
            xgb_trained = True
        except Exception as e:
            # Fall back if training fails
            warnings.warn(f"XGBoost training failed: {str(e)}")
            xgb_trained = False
            
    # Calculate Metrics for all trained models
    model_list = ["Linear Regression", "Random Forest"]
    if xgb_trained:
        model_list.append("XGBoost")
        
    for name in model_list:
        y_pred = predictions[name]
        mae = mean_absolute_error(y_test, y_pred)
        mse = mean_squared_error(y_test, y_pred)
        rmse = np.sqrt(mse)
        r2 = r2_score(y_test, y_pred)
        mape = calculate_mape(y_test, y_pred)
        
        results[name] = {
            "MAE": round(mae, 2),
            "MSE": round(mse, 2),
            "RMSE": round(rmse, 2),
            "R2": round(r2, 4),
            "MAPE": round(mape, 2)
        }
        
    # Create comparison dataframe
    df_metrics = pd.DataFrame(results).T
    
    # Determine the best-performing model based on RMSE
    best_model_name = df_metrics["RMSE"].idxmin()
    
    return df_metrics, models, predictions, importances, best_model_name

def forecast_recursive(model, last_known_row, num_months=12):
    """
    Forecasting future sales recursively using a trained machine learning regressor.
    """
    forecast_values = []
    
    # Start with the last known row's lag values
    # To forecast t+1:
    # Sales_Lag_1 = Sales at t
    # Sales_Lag_2 = Sales at t-1
    # Sales_Lag_3 = Sales at t-2
    # Sales_Lag_12 = Sales at t-11
    # Sales_Rolling_3 = Mean(Sales_Lag_1, Sales_Lag_2, Sales_Lag_3)
    # Sales_Rolling_6 = Mean(Sales_Lag_1..6)
    
    # We need a history of the last 12 months to compute lags
    history = list(last_known_row['history'])  # List of sales from t-11 to t
    last_date = pd.to_datetime(last_known_row['Order Date'])
    
    current_year = last_date.year
    current_month = last_date.month
    
    for i in range(num_months):
        # Move calendar month forward
        current_month += 1
        if current_month > 12:
            current_month = 1
            current_year += 1
            
        # Lags
        lag_1 = history[-1]
        lag_2 = history[-2]
        lag_3 = history[-3]
        lag_12 = history[-12]
        
        # Rolling means
        roll_3 = np.mean(history[-3:])
        roll_6 = np.mean(history[-6:])
        
        # Seasonal
        is_holiday = 1 if current_month in [11, 12] else 0
        is_q4 = 1 if current_month >= 10 else 0
        
        # Cyclical
        m_sin = np.sin(2 * np.pi * current_month / 12.0)
        m_cos = np.cos(2 * np.pi * current_month / 12.0)
        
        # Feature vector (matching column order of X_train)
        # ["Year", "Month", "Sales_Lag_1", "Sales_Lag_2", "Sales_Lag_3", "Sales_Lag_12",
        #  "Sales_Rolling_Mean_3", "Sales_Rolling_Mean_6", "Is_Holiday_Season", "Is_Q4", "Month_Sin", "Month_Cos"]
        features_df = pd.DataFrame([{
            "Year": current_year,
            "Month": current_month,
            "Sales_Lag_1": lag_1,
            "Sales_Lag_2": lag_2,
            "Sales_Lag_3": lag_3,
            "Sales_Lag_12": lag_12,
            "Sales_Rolling_Mean_3": roll_3,
            "Sales_Rolling_Mean_6": roll_6,
            "Is_Holiday_Season": is_holiday,
            "Is_Q4": is_q4,
            "Month_Sin": m_sin,
            "Month_Cos": m_cos
        }])
        
        # Predict next value
        pred_sales = model.predict(features_df)[0]
        # Prevent negative sales predictions
        pred_sales = max(0.0, pred_sales)
        
        forecast_values.append({
            "Order Date": pd.to_datetime(f"{current_year}-{current_month:02d}-01"),
            "Sales": pred_sales
        })
        
        # Update history
        history.append(pred_sales)
        
    return pd.DataFrame(forecast_values)
