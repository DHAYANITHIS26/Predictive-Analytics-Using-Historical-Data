import pandas as pd
import numpy as np
from fpdf import FPDF
import io

class ExecutiveReportPDF(FPDF):
    def header(self):
        # Draw top banner line
        self.set_fill_color(31, 58, 96) # Primary Navy
        self.rect(0, 0, 210, 8, "F")
        
        # Add Title text in header (if not on first page)
        if self.page_no() > 1:
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(150, 150, 150)
            self.cell(0, 10, "Sales Forecasting & Predictive Analytics Report", align="R")
            self.ln(10)

    def footer(self):
        # Position at 1.5 cm from bottom
        self.set_y(-15)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(128, 128, 128)
        # Page number
        self.cell(0, 10, f"Page {self.page_no()}", 0, 0, "C")
        # Print date on the right
        self.cell(0, 10, "Confidential - Commercial Use Only", 0, 0, "R")

def generate_pdf_report(cleaning_summary, kpis, model_metrics, forecast_data):
    """
    Generates a PDF bytes object using fpdf2 containing:
    1. Executive Summary & KPI Overview
    2. Data Cleaning Summary
    3. Machine Learning & Time Series Model Evaluation Comparison
    4. Next 12-Month Sales Forecast Table
    """
    pdf = ExecutiveReportPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    
    # --- PAGE 1: TITLE & EXECUTIVE SUMMARY ---
    pdf.add_page()
    
    # Title Block
    pdf.set_y(25)
    pdf.set_font("Helvetica", "B", 24)
    pdf.set_text_color(31, 58, 96) # Primary Navy
    pdf.cell(0, 12, "Executive Sales Forecast Report", ln=True, align="L")
    
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(100, 110, 120)
    pdf.cell(0, 8, "Predictive Analytics Dashboard Deliverable", ln=True, align="L")
    pdf.ln(5)
    
    # Horizontal line
    pdf.set_draw_color(31, 58, 96)
    pdf.set_line_width(1)
    pdf.line(10, pdf.get_y(), 200, pdf.get_y())
    pdf.ln(10)
    
    # Executive Summary Paragraph
    pdf.set_font("Helvetica", "", 10.5)
    pdf.set_text_color(51, 51, 51)
    summary_text = (
        "This analytics report presents a data-driven outlook of future sales trends developed from "
        "historical order transactions. By leveraging advanced machine learning algorithms "
        "and traditional time-series models, we have analyzed underlying trends, seasonality, "
        "and promotional impacts to forecast demand for the upcoming 12 months. The models are evaluated "
        "rigorously to support inventory management, marketing allocations, and operational planning."
    )
    pdf.multi_cell(0, 6, summary_text)
    pdf.ln(8)
    
    # KPI Section (Grid of boxes)
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(0, 8, "Key Performance Indicators (Historical)", ln=True)
    pdf.ln(3)
    
    # Row 1 of KPIs
    y_start = pdf.get_y()
    # Box 1: Total Revenue
    pdf.set_fill_color(240, 244, 248)
    pdf.rect(10, y_start, 60, 22, "F")
    pdf.set_xy(12, y_start + 3)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(56, 4, "TOTAL REVENUE", ln=True)
    pdf.set_x(12)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(56, 8, f"${kpis.get('total_sales', 0.0):,.2f}")
    
    # Box 2: Total Profit
    pdf.rect(75, y_start, 60, 22, "F")
    pdf.set_xy(77, y_start + 3)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(56, 4, "TOTAL NET PROFIT", ln=True)
    pdf.set_x(77)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(44, 160, 44) # Green
    pdf.cell(56, 8, f"${kpis.get('total_profit', 0.0):,.2f}")
    
    # Box 3: Total Orders
    pdf.rect(140, y_start, 60, 22, "F")
    pdf.set_xy(142, y_start + 3)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(56, 4, "TOTAL TRANSACTIONS", ln=True)
    pdf.set_x(142)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(214, 39, 40) # Red
    pdf.cell(56, 8, f"{kpis.get('total_orders', 0):,}")
    
    pdf.ln(25)
    
    # Row 2 of KPIs
    y_start2 = pdf.get_y()
    # Box 4: Average Order Value
    pdf.rect(10, y_start2, 60, 22, "F")
    pdf.set_xy(12, y_start2 + 3)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(56, 4, "AVG ORDER VALUE (AOV)", ln=True)
    pdf.set_x(12)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(56, 8, f"${kpis.get('avg_order_value', 0.0):,.2f}")
    
    # Box 5: Historical Profit Margin
    pdf.rect(75, y_start2, 60, 22, "F")
    pdf.set_xy(77, y_start2 + 3)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(56, 4, "PROFIT MARGIN %", ln=True)
    pdf.set_x(77)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(56, 8, f"{kpis.get('profit_margin', 0.0):.2f}%")
    
    # Box 6: Growth Rate
    pdf.rect(140, y_start2, 60, 22, "F")
    pdf.set_xy(142, y_start2 + 3)
    pdf.set_font("Helvetica", "", 8)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(56, 4, "AVG MONTHLY GROWTH", ln=True)
    pdf.set_x(142)
    pdf.set_font("Helvetica", "B", 12)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(56, 8, f"{kpis.get('growth_rate', 0.0):+.2f}%")
    
    pdf.ln(25)
    
    # Data Cleaning Summary Block
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(0, 8, "Data Preparation & Cleaning Summary", ln=True)
    pdf.ln(3)
    
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(51, 51, 51)
    
    # Write details of data cleaning
    pdf.cell(60, 6, f"- Original Row Count: {cleaning_summary.get('before_rows', 0):,}")
    pdf.cell(60, 6, f"- Cleaned Row Count: {cleaning_summary.get('after_rows', 0):,}")
    pdf.ln(6)
    pdf.cell(60, 6, f"- Duplicates Removed: {cleaning_summary.get('duplicates_removed', 0):,}")
    pdf.cell(60, 6, f"- Outliers Clipped (99th %): {cleaning_summary.get('outliers_clipped', 0)}")
    pdf.ln(6)
    pdf.cell(60, 6, f"- Missing Values Imputed: {cleaning_summary.get('missing_values_filled', 0)}")
    pdf.cell(60, 6, f"- Engineered Features: {cleaning_summary.get('engineered_features', 0)}")
    pdf.ln(10)
    
    # --- PAGE 2: MODEL EVALUATION & COMPARISON ---
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(0, 10, "Model Performance & Benchmarking", ln=True)
    pdf.ln(4)
    
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(51, 51, 51)
    pdf.multi_cell(0, 5, 
        "Each forecasting model was validated on a time-based holdout test set (typically the last 12 months "
        "of the historical data) to verify predictive capability on unseen periods. Below are the key metric comparisons "
        "including Mean Absolute Error (MAE), Root Mean Squared Error (RMSE), and R-squared (R2) score."
    )
    pdf.ln(5)
    
    # Model evaluation table
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_fill_color(31, 58, 96)
    pdf.set_text_color(255, 255, 255)
    
    # Header cells: Model, MAE, RMSE, R2, MAPE
    pdf.cell(60, 8, "Model Name", border=1, fill=True, align="L")
    pdf.cell(30, 8, "MAE ($)", border=1, fill=True, align="R")
    pdf.cell(30, 8, "RMSE ($)", border=1, fill=True, align="R")
    pdf.cell(30, 8, "R2 Score", border=1, fill=True, align="R")
    pdf.cell(30, 8, "MAPE (%)", border=1, fill=True, align="R")
    pdf.ln(8)
    
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(51, 51, 51)
    
    for idx, row in model_metrics.iterrows():
        # Check if it is the best model and apply subtle styling if so
        is_best = idx == kpis.get("best_model", "")
        if is_best:
            pdf.set_fill_color(230, 245, 230)
            pdf.set_font("Helvetica", "B", 9)
        else:
            pdf.set_fill_color(255, 255, 255)
            pdf.set_font("Helvetica", "", 9)
            
        r2_val = row["R2"]
        r2_str = f"{r2_val:.4f}" if isinstance(r2_val, float) else str(r2_val)
        
        pdf.cell(60, 7, f" {idx} {'(Best)' if is_best else ''}", border=1, fill=True, align="L")
        pdf.cell(30, 7, f"{row['MAE']}", border=1, fill=True, align="R")
        pdf.cell(30, 7, f"{row['RMSE']}", border=1, fill=True, align="R")
        pdf.cell(30, 7, r2_str, border=1, fill=True, align="R")
        pdf.cell(30, 7, f"{row['MAPE']}%", border=1, fill=True, align="R")
        pdf.ln(7)
        
    pdf.ln(10)
    
    # --- PAGE 3: 12-MONTH SALES FORECAST TABLE ---
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.set_text_color(31, 58, 96)
    pdf.cell(0, 10, "12-Month Future Demand Forecast", ln=True)
    pdf.ln(4)
    
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(51, 51, 51)
    pdf.multi_cell(0, 5, 
        "Below is the point-estimate forecast and corresponding 95% confidence intervals (Lower/Upper bounds) "
        "for overall monthly sales for the next 12 months. This forecast is computed using the highest-accuracy "
        "time-series model."
    )
    pdf.ln(5)
    
    # Forecast table header
    pdf.set_font("Helvetica", "B", 9)
    pdf.set_fill_color(31, 58, 96)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(50, 8, "Month", border=1, fill=True, align="L")
    pdf.cell(45, 8, "Forecasted Sales ($)", border=1, fill=True, align="R")
    pdf.cell(45, 8, "Lower Bound (95%)", border=1, fill=True, align="R")
    pdf.cell(45, 8, "Upper Bound (95%)", border=1, fill=True, align="R")
    pdf.ln(8)
    
    pdf.set_font("Helvetica", "", 9)
    pdf.set_text_color(51, 51, 51)
    
    # Fill table
    row_count = 0
    for _, row in forecast_data.iterrows():
        # Alternating background colors
        if row_count % 2 == 0:
            pdf.set_fill_color(248, 249, 250)
        else:
            pdf.set_fill_color(255, 255, 255)
            
        date_str = row["Order Date"].strftime("%B %Y")
        pdf.cell(50, 7, f" {date_str}", border=1, fill=True, align="L")
        pdf.cell(45, 7, f"${row['Sales']:,.2f}", border=1, fill=True, align="R")
        pdf.cell(45, 7, f"${row['Lower Bound']:,.2f}", border=1, fill=True, align="R")
        pdf.cell(45, 7, f"${row['Upper Bound']:,.2f}", border=1, fill=True, align="R")
        pdf.ln(7)
        row_count += 1
        
    pdf.ln(10)
    
    # Sign off
    pdf.set_font("Helvetica", "I", 9)
    pdf.set_text_color(100, 100, 100)
    pdf.cell(0, 5, "Report generated automatically by the Predictive Sales Forecasting Dashboard.", ln=True, align="C")
    
    # Output to binary buffer
    # Use 'dest="S"' to return bytes directly or write to file.
    # In newer fpdf2, pdf.output() returns bytearray / bytes or we can output to a buffer
    pdf_bytes = pdf.output()
    if isinstance(pdf_bytes, bytearray):
        pdf_bytes = bytes(pdf_bytes)
        
    return pdf_bytes
