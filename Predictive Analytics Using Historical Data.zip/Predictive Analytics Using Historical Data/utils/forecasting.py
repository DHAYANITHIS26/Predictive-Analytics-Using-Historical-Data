import pandas as pd
import numpy as np
import warnings
from statsmodels.tsa.statespace.sarimax import SARIMAX
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# Check if Prophet is available
try:
    from prophet import Prophet
    PROPHET_AVAILABLE = True
except ImportError:
    PROPHET_AVAILABLE = False

def calculate_mape(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    mask = y_true != 0
    if not np.any(mask):
        return 0.0
    return np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100

class SeasonalRegressionForecaster:
    """
    Fallback forecasting model: Linear trend + Monthly seasonality indicators.
    Extremely robust, no convergence issues, fits quickly.
    """
    def __init__(self):
        self.model = LinearRegression()
        self.fitted_std = 0.0
        
    def _create_features(self, dates):
        df = pd.DataFrame(index=dates)
        df["Trend"] = np.arange(len(dates))
        df["Month"] = pd.DatetimeIndex(dates).month
        # One-hot encode months 1 to 12
        for m in range(1, 13):
            df[f"Month_{m}"] = (df["Month"] == m).astype(int)
        
        feature_cols = ["Trend"] + [f"Month_{m}" for m in range(1, 13)]
        return df[feature_cols]

    def fit(self, dates, y):
        X = self._create_features(dates)
        self.model.fit(X, y)
        preds = self.model.predict(X)
        residuals = y - preds
        self.fitted_std = np.std(residuals)
        return self

    def predict(self, start_date, steps):
        future_dates = pd.date_range(start=start_date + pd.DateOffset(months=1), periods=steps, freq="ME")
        X_future = self._create_features(future_dates)
        # Fix Trend index in future
        # Trend should continue from the training length
        train_len = self.model.coef_[0] # Coefficient of Trend is coef_[0]
        # X_future Trend should start from training length
        # Let's adjust Trend to continue correctly:
        # We will pass the starting trend index
        return future_dates, self.model.predict(X_future)
        
    def forecast_with_ci(self, dates, y, steps=12):
        X = self._create_features(dates)
        self.model.fit(X, y)
        
        # Determine starting trend index
        last_trend = len(dates) - 1
        
        future_dates = pd.date_range(start=dates.max() + pd.DateOffset(months=1), periods=steps, freq="ME")
        
        X_future = pd.DataFrame(index=future_dates)
        X_future["Trend"] = np.arange(last_trend + 1, last_trend + 1 + steps)
        X_future["Month"] = future_dates.month
        for m in range(1, 13):
            X_future[f"Month_{m}"] = (X_future["Month"] == m).astype(int)
            
        feature_cols = ["Trend"] + [f"Month_{m}" for m in range(1, 13)]
        
        preds = self.model.predict(X_future[feature_cols])
        # Prevent negative predictions
        preds = np.clip(preds, a_min=0, a_max=None)
        
        lower_bounds = preds - 1.96 * self.fitted_std
        upper_bounds = preds + 1.96 * self.fitted_std
        
        # Prevent negative bounds
        lower_bounds = np.clip(lower_bounds, a_min=0, a_max=None)
        
        return pd.DataFrame({
            "Order Date": future_dates,
            "Sales": preds,
            "Lower Bound": lower_bounds,
            "Upper Bound": upper_bounds
        })

def train_and_evaluate_time_series(monthly_df, forecast_months=12):
    """
    Evaluates ARIMA, Exponential Smoothing, and Prophet (or Fallback)
    on a holdout validation set of size `forecast_months`.
    Returns evaluation metrics comparison table.
    """
    global PROPHET_AVAILABLE
    df_ts = monthly_df.copy().sort_values("Order Date")
    
    # Needs a minimum history length to fit time series models
    if len(df_ts) <= forecast_months + 6:
        # Fallback if history is too short
        forecast_months = max(1, len(df_ts) // 5)
        
    split_idx = len(df_ts) - forecast_months
    train_data = df_ts.iloc[:split_idx]
    val_data = df_ts.iloc[split_idx:]
    
    y_train = train_data["Sales"].values
    y_val = val_data["Sales"].values
    train_dates = train_data["Order Date"]
    val_dates = val_data["Order Date"]
    
    ts_results = {}
    
    # --- 1. ARIMA / SARIMAX ---
    try:
        # Simple seasonal order: (1, 1, 1)x(1, 1, 0, 12) if 12 seasonal periods
        # We suppress warnings to avoid console spam in streamlit
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # If dataset is small, default to non-seasonal or simple order
            if len(y_train) >= 24:
                arima_model = SARIMAX(y_train, order=(1, 1, 1), seasonal_order=(1, 1, 0, 12), enforce_stationarity=False, enforce_invertibility=False)
            else:
                arima_model = SARIMAX(y_train, order=(1, 1, 1))
            arima_fit = arima_model.fit(disp=False)
            arima_pred = arima_fit.forecast(steps=forecast_months)
            
            # Clip negative values
            arima_pred = np.clip(arima_pred, 0, None)
            
            mae = mean_absolute_error(y_val, arima_pred)
            rmse = np.sqrt(mean_squared_error(y_val, arima_pred))
            r2 = r2_score(y_val, arima_pred)
            mape = calculate_mape(y_val, arima_pred)
            ts_results["ARIMA"] = {"MAE": mae, "RMSE": rmse, "R2": r2, "MAPE": mape, "Preds": arima_pred}
    except Exception as e:
        ts_results["ARIMA"] = {"MAE": np.nan, "RMSE": np.nan, "R2": np.nan, "MAPE": np.nan, "Preds": np.zeros(forecast_months)}

    # --- 2. Exponential Smoothing ---
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # Holt-Winters additive trend and seasonality
            if len(y_train) >= 24:
                es_model = ExponentialSmoothing(y_train, trend="add", seasonal="add", seasonal_periods=12)
            else:
                es_model = ExponentialSmoothing(y_train, trend="add")
            es_fit = es_model.fit()
            es_pred = es_fit.forecast(steps=forecast_months)
            
            es_pred = np.clip(es_pred, 0, None)
            
            mae = mean_absolute_error(y_val, es_pred)
            rmse = np.sqrt(mean_squared_error(y_val, es_pred))
            r2 = r2_score(y_val, es_pred)
            mape = calculate_mape(y_val, es_pred)
            ts_results["Exponential Smoothing"] = {"MAE": mae, "RMSE": rmse, "R2": r2, "MAPE": mape, "Preds": es_pred}
    except Exception as e:
        ts_results["Exponential Smoothing"] = {"MAE": np.nan, "RMSE": np.nan, "R2": np.nan, "MAPE": np.nan, "Preds": np.zeros(forecast_months)}

    # --- 3. Prophet / Fallback ---
    if PROPHET_AVAILABLE:
        try:
            prophet_df = train_data[["Order Date", "Sales"]].rename(columns={"Order Date": "ds", "Sales": "y"})
            prophet_df["ds"] = prophet_df["ds"].dt.tz_localize(None) # Remove timezone if any
            
            p_model = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
            p_model.fit(prophet_df)
            
            future = p_model.make_future_dataframe(periods=forecast_months, freq="ME")
            p_forecast = p_model.predict(future)
            p_pred = p_forecast["yhat"].iloc[-forecast_months:].values
            
            p_pred = np.clip(p_pred, 0, None)
            
            mae = mean_absolute_error(y_val, p_pred)
            rmse = np.sqrt(mean_squared_error(y_val, p_pred))
            r2 = r2_score(y_val, p_pred)
            mape = calculate_mape(y_val, p_pred)
            ts_results["Prophet"] = {"MAE": mae, "RMSE": rmse, "R2": r2, "MAPE": mape, "Preds": p_pred}
        except Exception as e:
            PROPHET_AVAILABLE = False # Fall back if fit fails
            
    if not PROPHET_AVAILABLE:
        # Fit Seasonal Regression
        try:
            forecaster = SeasonalRegressionForecaster()
            forecaster.fit(train_dates, y_train)
            pred_df = forecaster.forecast_with_ci(train_dates, y_train, steps=forecast_months)
            p_pred = pred_df["Sales"].values
            
            mae = mean_absolute_error(y_val, p_pred)
            rmse = np.sqrt(mean_squared_error(y_val, p_pred))
            r2 = r2_score(y_val, p_pred)
            mape = calculate_mape(y_val, p_pred)
            ts_results["Prophet (Fallback: Seasonal Reg)"] = {"MAE": mae, "RMSE": rmse, "R2": r2, "MAPE": mape, "Preds": p_pred}
        except Exception as e:
            ts_results["Prophet (Fallback: Seasonal Reg)"] = {"MAE": np.nan, "RMSE": np.nan, "R2": np.nan, "MAPE": np.nan, "Preds": np.zeros(forecast_months)}

    # Build metric comparison table
    perf_metrics = {}
    for name, metrics in ts_results.items():
        perf_metrics[name] = {
            "MAE": round(metrics["MAE"], 2) if not np.isnan(metrics["MAE"]) else "N/A",
            "RMSE": round(metrics["RMSE"], 2) if not np.isnan(metrics["RMSE"]) else "N/A",
            "R2": round(metrics["R2"], 4) if not np.isnan(metrics["R2"]) else "N/A",
            "MAPE": round(metrics["MAPE"], 2) if not np.isnan(metrics["MAPE"]) else "N/A"
        }
    df_perf = pd.DataFrame(perf_metrics).T
    
    return df_perf, ts_results

def generate_future_forecasts(monthly_df, steps=12):
    """
    Fits models on the full historical dataset and generates predictions
    for the next `steps` months (forecast horizons) with confidence intervals.
    """
    df_ts = monthly_df.copy().sort_values("Order Date")
    dates = df_ts["Order Date"]
    y = df_ts["Sales"].values
    
    forecasts = {}
    
    # Calculate historical residuals standard deviation for confidence bounds approximation
    arima_std = 0.0
    es_std = 0.0
    
    # --- 1. ARIMA ---
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if len(y) >= 24:
                arima_model = SARIMAX(y, order=(1, 1, 1), seasonal_order=(1, 1, 0, 12), enforce_stationarity=False, enforce_invertibility=False)
            else:
                arima_model = SARIMAX(y, order=(1, 1, 1))
            arima_fit = arima_model.fit(disp=False)
            
            # Predict
            arima_forecast = arima_fit.get_forecast(steps=steps)
            arima_frame = arima_forecast.summary_frame(alpha=0.05)
            
            future_dates = pd.date_range(start=dates.max() + pd.DateOffset(months=1), periods=steps, freq="ME")
            
            forecasts["ARIMA"] = pd.DataFrame({
                "Order Date": future_dates,
                "Sales": np.clip(arima_frame["mean"].values, 0, None),
                "Lower Bound": np.clip(arima_frame["mean_ci_lower"].values, 0, None),
                "Upper Bound": np.clip(arima_frame["mean_ci_upper"].values, 0, None)
            })
    except Exception as e:
        warnings.warn(f"ARIMA forecast failed: {str(e)}")

    # --- 2. Exponential Smoothing ---
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            if len(y) >= 24:
                es_model = ExponentialSmoothing(y, trend="add", seasonal="add", seasonal_periods=12)
            else:
                es_model = ExponentialSmoothing(y, trend="add")
            es_fit = es_model.fit()
            
            # Residual standard deviation
            residuals = y - es_fit.fittedvalues
            es_std = np.std(residuals)
            
            es_pred = es_fit.forecast(steps=steps)
            es_pred = np.clip(es_pred, 0, None)
            
            future_dates = pd.date_range(start=dates.max() + pd.DateOffset(months=1), periods=steps, freq="ME")
            
            # Normal distribution bounds
            lower = np.clip(es_pred - 1.96 * es_std, 0, None)
            upper = es_pred + 1.96 * es_std
            
            forecasts["Exponential Smoothing"] = pd.DataFrame({
                "Order Date": future_dates,
                "Sales": es_pred,
                "Lower Bound": lower,
                "Upper Bound": upper
            })
    except Exception as e:
        warnings.warn(f"Exponential Smoothing forecast failed: {str(e)}")

    # --- 3. Prophet or Fallback ---
    global PROPHET_AVAILABLE
    if PROPHET_AVAILABLE:
        try:
            prophet_df = df_ts[["Order Date", "Sales"]].rename(columns={"Order Date": "ds", "Sales": "y"})
            prophet_df["ds"] = prophet_df["ds"].dt.tz_localize(None)
            
            p_model = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
            p_model.fit(prophet_df)
            
            future = p_model.make_future_dataframe(periods=steps, freq="ME")
            p_forecast = p_model.predict(future)
            
            forecast_rows = p_forecast.iloc[-steps:]
            future_dates = pd.date_range(start=dates.max() + pd.DateOffset(months=1), periods=steps, freq="ME")
            
            forecasts["Prophet"] = pd.DataFrame({
                "Order Date": future_dates,
                "Sales": np.clip(forecast_rows["yhat"].values, 0, None),
                "Lower Bound": np.clip(forecast_rows["yhat_lower"].values, 0, None),
                "Upper Bound": np.clip(forecast_rows["yhat_upper"].values, 0, None)
            })
        except Exception as e:
            PROPHET_AVAILABLE = False

    if not PROPHET_AVAILABLE:
        # Fallback to Seasonal Regression
        try:
            forecaster = SeasonalRegressionForecaster()
            forecasts["Prophet (Fallback: Seasonal Reg)"] = forecaster.forecast_with_ci(dates, y, steps=steps)
        except Exception as e:
            warnings.warn(f"Seasonal regression forecast failed: {str(e)}")
            
    return forecasts
