import pandas as pd
import numpy as np
import os
import sys

# Configure UTF-8 encoding on Windows to prevent UnicodeEncodeError with emojis
if sys.platform.startswith("win") and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

# Append local path to make sure imports work if run directly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.data_loader import load_data, validate_schema, clean_data, prepare_monthly_data
from utils.models import prepare_train_test_split, train_and_evaluate_models
from utils.forecasting import train_and_evaluate_time_series, generate_future_forecasts
from utils.report_generator import generate_pdf_report
from utils.eda_plots import plot_sales_vs_profit_scatter

def main():
    print("🚀 Starting sales forecasting pipeline validation...")
    
    # 1. Check if dataset exists
    data_path = "data/sample_sales_data.csv"
    if not os.path.exists(data_path):
        print(f"❌ Dataset not found at {data_path}. Running generator first.")
        import generate_sample_data
        
    print(f"✅ Dataset located at {data_path}")
    
    # 2. Test Loader and Schema Validator
    df_raw = pd.read_csv(data_path)
    is_valid, missing = validate_schema(df_raw)
    if not is_valid:
        print(f"❌ Schema validation failed. Missing: {missing}")
        sys.exit(1)
    print("✅ Schema validation: PASSED")
    
    # 3. Test Cleaning
    df_cleaned = clean_data(df_raw)
    print(f"✅ Data cleaning: PASSED ({len(df_raw)} raw rows -> {len(df_cleaned)} cleaned rows)")
    
    # Test scatter plot generation
    fig_scatter = plot_sales_vs_profit_scatter(df_cleaned)
    print("✅ Scatter plot generation: PASSED")
    
    # 4. Test Monthly Preparation
    df_monthly = prepare_monthly_data(df_cleaned)
    print(f"✅ Monthly data aggregation: PASSED ({len(df_monthly)} months)")
    
    # 5. Test ML Model Training
    X_train, X_test, y_train, y_test, dates_train, dates_test, features = prepare_train_test_split(df_monthly, test_months=12)
    metrics_ml, models, predictions, importances, best_ml = train_and_evaluate_models(
        X_train, X_test, y_train, y_test, tune_hyperparameters=False
    )
    print("✅ ML Model Training: PASSED")
    print("--- ML Metrics ---")
    print(metrics_ml)
    print(f"Best ML Model: {best_ml}")
    
    # 6. Test Time Series Models
    ts_perf, ts_res = train_and_evaluate_time_series(df_monthly, forecast_months=12)
    forecasts = generate_future_forecasts(df_monthly, steps=12)
    print("✅ Time Series Models: PASSED")
    print("--- Time Series Metrics ---")
    print(ts_perf)
    
    # 7. Test PDF Generation
    kpis = {
        "total_sales": df_cleaned["Sales"].sum(),
        "total_profit": df_cleaned["Profit"].sum(),
        "total_orders": len(df_cleaned),
        "avg_order_value": df_cleaned["Sales"].mean(),
        "profit_margin": (df_cleaned["Profit"].sum() / df_cleaned["Sales"].sum()) * 100,
        "growth_rate": 5.4,
        "best_model": best_ml
    }
    
    combined_metrics = pd.concat([metrics_ml, ts_perf])
    selected_ts_model = list(forecasts.keys())[0]
    forecast_df = forecasts[selected_ts_model]
    
    cleaning_summary = {
        "before_rows": len(df_raw),
        "after_rows": len(df_cleaned),
        "duplicates_removed": len(df_raw) - len(df_cleaned),
        "outliers_clipped": "Clipped top 1% (Quantity, Price, Sales)",
        "missing_values_filled": 0,
        "engineered_features": 6
    }
    
    try:
        pdf_bytes = generate_pdf_report(cleaning_summary, kpis, combined_metrics, forecast_df)
        print(f"✅ PDF Report Generation: PASSED ({len(pdf_bytes)} bytes)")
    except Exception as e:
        print(f"❌ PDF Report Generation FAILED: {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
        
    print("\n🎉 ALL PIPELINE VERIFICATIONS PASSED SUCCESSFULLY!")

if __name__ == "__main__":
    main()
